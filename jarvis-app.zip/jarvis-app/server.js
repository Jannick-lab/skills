// JARVIS – kleiner lokaler Server
// Start:  node server.js   (Node.js 18 oder neuer, keine weiteren Pakete nötig)
// Aufgabe: liefert das Dashboard aus und reicht Text an ElevenLabs weiter.
// Der API-Key bleibt hier auf deinem Rechner und landet nie im Browser.

const http = require('http');
const fs = require('fs');
const path = require('path');

// --- Einstellungen aus einstellungen.txt lesen -------------------------------
function loadSettings() {
  const file = path.join(__dirname, 'einstellungen.txt');
  const out = {};
  if (!fs.existsSync(file)) return out;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i < 1) continue;
    out[t.slice(0, i).trim()] = t.slice(i + 1).trim().replace(/^["']|["']$/g, '');
  }
  return out;
}

const cfg = loadSettings();
const API_KEY = process.env.ELEVENLABS_API_KEY || cfg.ELEVENLABS_API_KEY || '';
const VOICE_ID = cfg.VOICE_ID || 'JBFqnCBsd6RMkjVDRZzb';
const MODEL_ID = cfg.MODEL_ID || 'eleven_multilingual_v2';
const PORT = Number(cfg.PORT) || 3000;
const MAX_CHARS = 600; // schützt dein Zeichen-Kontingent vor versehentlich langen Texten

const keySet = API_KEY !== '' && !API_KEY.includes('HIER_');

function sendJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 20000) { reject(new Error('zu groß')); req.destroy(); }
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

async function speak(req, res) {
  if (!keySet) {
    return sendJson(res, 500, { error: 'Kein API-Key gefunden. Trage ihn in einstellungen.txt ein und starte den Server neu.' });
  }
  let text = '';
  try {
    text = String(JSON.parse(await readBody(req)).text || '').trim();
  } catch (e) {
    return sendJson(res, 400, { error: 'Ungültige Anfrage.' });
  }
  if (!text) return sendJson(res, 400, { error: 'Kein Text übergeben.' });
  text = text.slice(0, MAX_CHARS);

  let r;
  try {
    r = await fetch(
      'https://api.elevenlabs.io/v1/text-to-speech/' + encodeURIComponent(VOICE_ID) + '?output_format=mp3_44100_128',
      {
        method: 'POST',
        headers: { 'xi-api-key': API_KEY, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
        body: JSON.stringify({ text: text, model_id: MODEL_ID }),
      }
    );
  } catch (e) {
    return sendJson(res, 502, { error: 'ElevenLabs ist nicht erreichbar. Besteht eine Internetverbindung?' });
  }

  if (!r.ok) {
    const detail = (await r.text()).slice(0, 300);
    console.error('ElevenLabs-Fehler', r.status, detail);
    let msg = 'ElevenLabs meldet Fehler ' + r.status + '.';
    if (r.status === 401) msg = 'Der API-Key wurde abgelehnt. Bitte in einstellungen.txt prüfen.';
    if (r.status === 404) msg = 'Die Stimme (VOICE_ID) wurde nicht gefunden.';
    if (r.status === 429) msg = 'Zu viele Anfragen oder Kontingent aufgebraucht.';
    return sendJson(res, 502, { error: msg });
  }

  const audio = Buffer.from(await r.arrayBuffer());
  res.writeHead(200, { 'Content-Type': 'audio/mpeg', 'Content-Length': audio.length, 'Cache-Control': 'no-store' });
  res.end(audio);
}

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return fs.createReadStream(path.join(__dirname, 'index.html')).pipe(res);
  }
  if (req.method === 'GET' && url === '/api/status') {
    return sendJson(res, 200, { keySet: keySet });
  }
  if (req.method === 'POST' && url === '/api/speak') {
    return speak(req, res).catch((e) => {
      console.error(e);
      if (!res.headersSent) sendJson(res, 500, { error: 'Interner Fehler im Server.' });
    });
  }
  sendJson(res, 404, { error: 'Nicht gefunden.' });
});

// 127.0.0.1 = nur von diesem Rechner aus erreichbar.
server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  JARVIS läuft:  http://localhost:' + PORT);
  console.log('  API-Key:       ' + (keySet ? 'gefunden' : 'FEHLT – bitte in einstellungen.txt eintragen'));
  console.log('  Beenden mit Strg + C');
  console.log('');
});
